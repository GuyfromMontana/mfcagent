# MFC Voice Agent with Zep Memory Integration

Complete deployment guide for adding memory to your Montana Feed Company voice agent.

## 📋 What This Does

Your voice agent will now:
- **Remember returning callers** - "Hey! How did that Range Mineral work out?"
- **Track ranch details** - Herd size, location, previous issues
- **Build relationships over time** - Understand customer history and preferences
- **Provide personalized service** - Reference past conversations naturally

## 🚀 Deployment Steps

### Step 1: Get Your Zep API Key

1. Go to https://www.getzep.com/
2. Sign up for a free account (1,000 users free)
3. Navigate to your dashboard
4. Copy your API key

### Step 2: Set Up Environment Variables in Railway

1. Go to your Railway dashboard
2. Click on your project
3. Go to "Variables" tab
4. Add this variable:
   ```
   ZEP_API_KEY = paste_your_key_here
   ```

### Step 3: Upload Your Code to Railway

**Option A: Using Git (Recommended)**
```bash
# In your project folder
git add .
git commit -m "Add Zep memory integration"
git push
```

**Option B: Railway CLI**
```bash
railway up
```

**Option C: Manual Upload**
- Zip your project folder
- Upload through Railway dashboard

### Step 4: Configure Vapi to Use Memory

#### A. Set Up Assistant Webhook

In your Vapi assistant settings:

1. **Server URL** (for getting caller context):
   ```
   https://your-railway-app.railway.app/get-caller-context
   ```

2. **Server Message** - Add this JSON structure:
   ```json
   {
     "phone_number": "{{call.customer.number}}"
   }
   ```

#### B. Update System Prompt

Modify your Vapi system prompt to include:

```
You are a Montana Feed Company nutrition specialist.

{{CALLER_CONTEXT}}

IMPORTANT: Use the caller context above to personalize the conversation. 
If this is a returning caller, reference their previous conversations naturally.
Don't recite facts like a list - work them into the conversation naturally.

Examples:
- "How'd that mineral supplement work out for you?"
- "Last time we talked, you mentioned those thin cows..."
- "I remember you're up in Granite County - how's the weather been?"

[Rest of your existing personality and guidelines...]
```

#### C. Add End-of-Call Webhook

In Vapi, set up webhook for "call.ended" event:

1. **Webhook URL**:
   ```
   https://your-railway-app.railway.app/save-conversation
   ```

2. **Webhook sends**: Full transcript + metadata

## 🧪 Testing Your Memory System

### Test 1: First Call
1. Call your Vapi number
2. Have a conversation about cattle nutrition
3. Mention specific details (herd size, location, problem)
4. End the call

### Test 2: Second Call (Same Number)
1. Call again from the same phone number
2. The agent should:
   - Recognize you as a returning caller
   - Reference your previous conversation
   - Remember details you mentioned

### Test 3: Check What's Stored
Visit this URL in your browser:
```
https://your-railway-app.railway.app/get-user-facts/+14065551234
```
(Replace with actual phone number)

You'll see all facts Zep has learned about that caller.

## 📊 What Gets Remembered

### Automatically Extracted by Zep:
- **Ranch details**: Herd size, location, operation type
- **Problems discussed**: Thin cows, calving issues, nutrition questions
- **Products recommended**: Which Purina products were suggested
- **Specialist info**: Which territory specialist they work with
- **Seasonal context**: Time of year, weather, calving season
- **Follow-up needs**: What to check on next call

### Structured Data You Can Add:
Using the `/add-ranch-data` endpoint, you can manually add:
- Ranch name
- Exact location (county)
- Herd size
- Operation type (cow-calf, backgrounding, etc.)
- Assigned specialist name

## 🔧 Advanced Configuration

### Fact Rating (Prioritize Important Information)

Add this to your code to rate facts by importance:

```python
from zep_cloud.types import FactRatingInstruction, FactRatingExamples

fact_rating = FactRatingInstruction(
    instruction="""Rate facts by importance to ranch operations.
    
    High importance: Herd size changes, health problems, major purchases
    Medium importance: Seasonal changes, product switches
    Low importance: Weather chat, general questions
    """,
    examples=FactRatingExamples(
        high="Rancher lost 15 calves to scours during calving season",
        medium="Switched from Range Mineral to AccuTerm in November",
        low="Asked about weather forecast for next week"
    )
)

# Use when adding session
await zep.memory.add_session(
    user_id=user_id,
    session_id=session_id,
    fact_rating_instruction=fact_rating
)
```

## 🎯 Integration with Salesforce (Future)

When you get Salesforce access, the architecture becomes:

```
Call comes in → Railway API
                ↓
    Get memory from Zep
    Get customer from Salesforce
                ↓
    Combine both contexts
                ↓
    Send to Vapi agent
                ↓
    After call: Update both Zep + Salesforce
```

Your current Zep setup will work seamlessly with Salesforce. Just add Salesforce API calls to your Railway backend.

## 📈 Monitoring

### Check Logs in Railway:
```
railway logs
```

Look for:
- `📞 Incoming call from: +14065551234`
- `✓ Found existing caller`
- `✓ Retrieved memory context (5 facts)`
- `💾 Saving conversation`

### Common Issues:

**Issue**: "ZEP_API_KEY not set"
- **Fix**: Add the environment variable in Railway dashboard

**Issue**: "User not found" 
- **Fix**: This is normal for first-time callers

**Issue**: "Memory context empty"
- **Fix**: Zep takes a few minutes to process conversations. Second call will have memory.

## 💰 Cost Estimate

### Zep Pricing:
- **Free**: 1,000 users (phone numbers)
- **Paid**: $99/month for 10,000 users
- Each unique phone number = 1 user

### For MFC:
- Estimate 500 active customers calling
- You'd be well under the paid tier limit
- Much cheaper than building custom memory

## 🆘 Support

If you run into issues:

1. **Check Railway logs**: `railway logs`
2. **Test endpoints directly**: Visit `/health` endpoint
3. **Check Zep dashboard**: See what's being stored
4. **Test with curl**:
   ```bash
   curl -X POST https://your-app.railway.app/get-caller-context \
     -H "Content-Type: application/json" \
     -d '{"phone_number": "+14065551234"}'
   ```

## 📝 Files You Need

Make sure your project has:
- ✅ `mfc_zep_integration.py` (the main API code)
- ✅ `requirements.txt` (with zep-cloud==3.10.0)
- ✅ `.env` (local testing only - not deployed)
- ✅ `README.md` (this file)

## 🎉 You're Ready!

Once deployed, your MFC voice agent will remember every caller and provide personalized service that feels genuinely helpful - not like a chatbot.

The Montana rancher who called about thin cows will be recognized when they call back, and your agent will naturally ask how things worked out. That's the power of memory.
